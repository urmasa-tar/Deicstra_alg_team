﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Office.Interop.Excel;
using System.Windows.Forms;

namespace TestFileExcel
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            readExcel();
        }

        private void readExcel()
        {
            string filePath = "D:\\TestExcel\\ExcelTest.xlsx";
            Microsoft.Office.Interop.Excel.Application excel = new Microsoft.Office.Interop.Excel.Application();
            Workbook workb; // объявляем (создаем) новую книгу
            Worksheet worksh; // создаем рабочий лист
            
            workb = excel.Workbooks.Open(filePath);
            worksh = workb.Worksheets[1];


            //Range cell = worksh.Cells[1, 1];
            Range cell = worksh.Range["A2:D129"]; // Подучение значения из ячейки
            //Range cel1 = worksh.Cells[2, 1];
            //string CellValue = cell.Value;

            // int CelValue = cel1.Value;
            foreach (int Result in cell.Value)
            {
                MessageBox.Show(Convert.ToString(Result));
            }
            workb.Close();
            excel.Quit();
            //MessageBox.Show(Convert.ToString(CelValue));
            //Range cell = worksh.Range["A1"]; // Подучение значения из ячейки
            //foreach (string Result in cell.Value)
            //{
            //  MessageBox.Show(Result);
            //}
            //string CelValue = cell.Value;
            //MessageBox.Show(CelValue);

        } 
    }
}
